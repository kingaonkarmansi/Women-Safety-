const videoForm = document.getElementById('videoForm');
const videoURL = document.getElementById('videoURL');
const videoList = document.getElementById('videoList');

function extractYouTubeID(url) {
  const regex = /(?:youtube\\.com\\/(?:[^\\/\\n\\s]+\\/\\S+\\/|(?:v|e(?:mbed)?)\\/|.*[?&]v=)|youtu\\.be\\/)([\\w-]{11})/;
  const match = url.match(regex);
  return match ? match[1] : null;
}

videoForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const videoID = extractYouTubeID(videoURL.value);
  if (videoID) {
    const iframe = document.createElement('iframe');
    iframe.src = `https://www.youtube.com/embed/${videoID}`;
    iframe.allowFullscreen = true;
    const div = document.createElement('div');
    div.classList.add('video-item');
    div.appendChild(iframe);
    videoList.prepend(div);
    videoURL.value = '';
  } else {
    alert('Please enter a valid YouTube URL.');
  }
});
