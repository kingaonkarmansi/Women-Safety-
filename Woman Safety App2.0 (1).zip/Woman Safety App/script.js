// Function to simulate getting the user's current location
document.getElementById("get-location-btn").addEventListener("click", () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        document.getElementById(
          "location-status"
        ).textContent = `Location: Latitude ${latitude}, Longitude ${longitude}`;
      },
      () => {
        document.getElementById(
          "location-status"
        ).textContent = "Unable to fetch location. Please enable GPS.";
      }
    );
  } else {
    document.getElementById("location-status").textContent =
      "Geolocation is not supported by your browser.";
  }
});



// Function to send an SOS alert to the nearest police station
document.getElementById("sos-btn").addEventListener("click", () => {
  const locationStatus = document.getElementById("location-status").textContent;

  if (locationStatus.startsWith("Location:")) {
    const match = locationStatus.match(/Latitude ([-0-9.]+), Longitude ([-0-9.]+)/);
    const latitude = match[1];
    const longitude = match[2];

    // Use Google Maps Places API to find the nearest police station
    const googleMapsUrl = `https://www.google.com/maps/search/Police+Station/@${latitude},${longitude},15z`;

    // Construct SOS message
    const sosMessage = `Help! I need assistance. My current location is Latitude ${latitude}, Longitude ${longitude}. Find the nearest police station: ${googleMapsUrl}`;

    // Ask the user how they want to send the SOS message
    const shareOption = confirm("Do you want to send the SOS message via WhatsApp? Cancel for Email.");

    if (shareOption) {
      // Open WhatsApp
      const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(sosMessage)}`;
      window.open(whatsappUrl, "_blank");
    } else {
      // Open Email
      const emailSubject = "SOS Alert - Help Needed";
      const emailBody = sosMessage;
      const mailtoUrl = `mailto:?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoUrl, "_blank");
    }
  } else {
    alert("Please fetch your location first!");
  }
});


// Function to send location via WhatsApp or Email
document.getElementById("send-location-btn").addEventListener("click", () => {
  const locationStatus = document.getElementById("location-status").textContent;

  if (locationStatus.startsWith("Location:")) {
    const locationUrl = `https://maps.google.com/?q=${locationStatus.match(/Latitude ([-0-9.]+), Longitude ([-0-9.]+)/)[1]},${locationStatus.match(/Latitude ([-0-9.]+), Longitude ([-0-9.]+)/)[2]}`;

    const shareOption = confirm("Do you want to share via WhatsApp? Cancel for Email.");

    if (shareOption) {
      // Open WhatsApp
      const whatsappUrl = `https://api.whatsapp.com/send?text=My%20current%20location:%20${encodeURIComponent(locationUrl)}`;
      window.open(whatsappUrl, "_blank");
    } else {
      // Open Email
      const emailSubject = "My Current Location";
      const emailBody = `Here is my current location: ${locationUrl}`;
      const mailtoUrl = `mailto:?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoUrl, "_blank");
    }
  } else {
    alert("Please fetch your location first!");
  }
});

// Function to simulate SOS Alert
document.getElementById("sos-btn").addEventListener("click", () => {
  alert("SOS Alert Sent! Help is on the way.");
});

// Add new contact functionality
document.getElementById("add-contact-btn").addEventListener("click", () => {
  const newContact = prompt("Enter the name and number of the new contact:");
  if (newContact) {
    const contactList = document.getElementById("contacts-list");
    const newLi = document.createElement("li");
    newLi.textContent = newContact;
    contactList.appendChild(newLi);
  }
});
// Function to simulate getting the user's current location
document.getElementById("get-location-btn").addEventListener("click", () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        document.getElementById(
          "location-status"
        ).textContent = `Location: Latitude ${latitude}, Longitude ${longitude}`;
      },
      () => {
        document.getElementById(
          "location-status"
        ).textContent = "Unable to fetch location. Please enable GPS.";
      }
    );
  } else {
    document.getElementById("location-status").textContent =
      "Geolocation is not supported by your browser.";
  }
});

// Function to send location via WhatsApp or Email
document.getElementById("send-location-btn").addEventListener("click", () => {
  const locationStatus = document.getElementById("location-status").textContent;

  if (locationStatus.startsWith("Location:")) {
    const locationUrl = `https://maps.google.com/?q=${locationStatus.match(/Latitude ([-0-9.]+), Longitude ([-0-9.]+)/)[1]},${locationStatus.match(/Latitude ([-0-9.]+), Longitude ([-0-9.]+)/)[2]}`;
    
    const shareOption = confirm("Do you want to share via WhatsApp? Cancel for Email.");

    if (shareOption) {
      // Open WhatsApp
      const whatsappUrl = `https://api.whatsapp.com/send?text=My%20current%20location:%20${encodeURIComponent(locationUrl)}`;
      window.open(whatsappUrl, "_blank");
    } else {
      // Open Email
      const emailSubject = "My Current Location";
      const emailBody = `Here is my current location: ${locationUrl}`;
      const mailtoUrl = `mailto:?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoUrl, "_blank");
    }
  } else {
    alert("Please fetch your location first!");
  }
});

// Function to simulate SOS Alert
document.getElementById("sos-btn").addEventListener("click", () => {
  alert("SOS Alert Sent! Help is on the way.");
});

// Add new contact functionality (basic implementation)
document.getElementById("add-contact-btn").addEventListener("click", () => {
  const newContact = prompt("Enter the name and number of the new contact:");
  if (newContact) {
    const contactList = document.getElementById("contacts-list");
    const newLi = document.createElement("li");
    newLi.textContent = newContact;
    contactList.appendChild(newLi);
  }
});




// // toher js code
// // Emergency Contact
// document.getElementById('add-contact-btn').addEventListener('click', () => {
//   alert('Feature under development!');
// });

// // GPS Tracking
// document.getElementById('get-location-btn').addEventListener('click', () => {
//   if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//           document.getElementById('location-status').innerText = 
//             `Latitude: ${position.coords.latitude}, Longitude: ${position.coords.longitude}`;
//       }, (error) => {
//           alert('Unable to fetch location: ' + error.message);
//       });
//   } else {
//       alert('Geolocation is not supported by this browser.');
//   }
// });

// document.getElementById('send-location-btn').addEventListener('click', () => {
//   alert('Your location has been sent to your emergency contacts.');
// });

// // SOS Button
// document.getElementById('sos-btn').addEventListener('click', () => {
//   alert('SOS Alert has been sent!');
// });

// // Nearby Safe Zones
// document.getElementById('find-safe-zones-btn').addEventListener('click', () => {
//   if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//           const lat = position.coords.latitude;
//           const lng = position.coords.longitude;
//           const mapsUrl = `https://www.google.com/maps/search/hospital+or+police+station/@${lat},${lng},14z`;
//           window.open(mapsUrl, '_blank');
//       }, (error) => {
//           alert('Error fetching location: ' + error.message);
//       });
//   } else {
//       alert('Geolocation is not supported by your browser.');
//   }
// });

// // Report Unsafe Area
// document.getElementById('report-unsafe-btn').addEventListener('click', () => {
//   const description = document.getElementById('unsafe-description').value.trim();

//   if (!description) {
//       alert('Please enter a description before reporting.');
//       return;
//   }

//   if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//           const report = {
//               description: description,
//               latitude: position.coords.latitude,
//               longitude: position.coords.longitude,
//               timestamp: new Date().toLocaleString()
//           };
//           console.log('Report Sent:', report);
//           alert('Thank you for reporting the unsafe area! Your input has been noted.');
//           document.getElementById('unsafe-description').value = '';
//       }, (error) => {
//           alert('Failed to fetch your location: ' + error.message);
//       });
//   } else {
//       alert('Geolocation is not supported by this browser.');
//   }
// });




//third js code
// Emergency Contact
document.getElementById('add-contact-btn').addEventListener('click', () => {
  alert('Feature under development!');
});

// GPS Tracking
document.getElementById('get-location-btn').addEventListener('click', () => {
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
          document.getElementById('location-status').innerText = 
            `Latitude: ${position.coords.latitude}, Longitude: ${position.coords.longitude}`;
      }, (error) => {
          alert('Unable to fetch location: ' + error.message);
      });
  } else {
      alert('Geolocation is not supported by this browser.');
  }
});

document.getElementById('send-location-btn').addEventListener('click', () => {
  alert('Your location has been sent to your emergency contacts.');
});

// SOS Button
document.getElementById('sos-btn').addEventListener('click', () => {
  alert('SOS Alert has been sent!');
});

// Nearby Safe Zones
document.getElementById('find-safe-zones-btn').addEventListener('click', () => {
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const mapsUrl = `https://www.google.com/maps/search/hospital+or+police+station/@${lat},${lng},14z`;
          window.open(mapsUrl, '_blank');
      }, (error) => {
          alert('Error fetching location: ' + error.message);
      });
  } else {
      alert('Geolocation is not supported by your browser.');
  }
});

// // Report Unsafe Area with Mailto
// document.getElementById('report-unsafe-btn').addEventListener('click', () => {
//   const description = document.getElementById('unsafe-description').value.trim();

//   if (!description) {
//       alert('Please enter a description before reporting.');
//       return;
//   }

//   if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//           const lat = position.coords.latitude;
//           const lng = position.coords.longitude;
//           const timestamp = new Date().toLocaleString();

//           const templateParams = {
//               to_email: 'dbscholarhub@gmail.com',
//               subject: 'Unsafe Area Report',
//               message: `Description: ${description}\nLatitude: ${lat}\nLongitude: ${lng}\nTime: ${timestamp}`
//           };

//           emailjs.send('service_omjyzzn', 'template_3sxdy0v', templateParams)
//               .then(function(response) {
//                   alert('Report sent successfully!');
//               }, function(error) {
//                   alert('Failed to send report: ' + JSON.stringify(error));
//               });

//       }, (error) => {
//           alert('Failed to fetch your location: ' + error.message);
//       });
//   } else {
//       alert('Geolocation is not supported by your browser.');
//   }
// });


// Initialize EmailJS with your Public Key
(function() {
  emailjs.init('s-YzKNJQcVc7SeGHm'); // Replace YOUR_PUBLIC_KEY
})();

// Emergency Contact Feature
document.getElementById('add-contact-btn').addEventListener('click', () => {
  alert('Feature under development!');
});

// GPS Tracking
document.getElementById('get-location-btn').addEventListener('click', () => {
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
          document.getElementById('location-status').innerText =
            `Latitude: ${position.coords.latitude}, Longitude: ${position.coords.longitude}`;
      }, (error) => {
          alert('Unable to fetch location: ' + error.message);
      });
  } else {
      alert('Geolocation is not supported by this browser.');
  }
});

document.getElementById('send-location-btn').addEventListener('click', () => {
  alert('Your location has been sent to your emergency contacts.');
});

// SOS Alert Feature
document.getElementById('sos-btn').addEventListener('click', () => {
  alert('SOS Alert has been sent!');
});

// Nearby Safe Zones Feature
document.getElementById('find-safe-zones-btn').addEventListener('click', () => {
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const mapsUrl = `https://www.google.com/maps/search/hospital+or+police+station/@${lat},${lng},14z`;
          window.open(mapsUrl, '_blank');
      }, (error) => {
          alert('Error fetching location: ' + error.message);
      });
  } else {
      alert('Geolocation is not supported by your browser.');
  }
});

// // Report Unsafe Area with EmailJS
// document.getElementById('report-unsafe-btn').addEventListener('click', () => {
//   const description = document.getElementById('unsafe-description').value.trim();

//   if (!description) {
//       alert('Please enter a description before reporting.');
//       return;
//   }

//   if (navigator.geolocation) {
//       navigator.geolocation.getCurrentPosition((position) => {
//           const templateParams = {
//               description: description,
//               latitude: position.coords.latitude,
//               longitude: position.coords.longitude,
//               timestamp: new Date().toLocaleString()
//           };

//           emailjs.send('service_omjyzzn', 'template_3sxdy0v', templateParams) // Replace YOUR_SERVICE_ID and YOUR_TEMPLATE_ID
//               .then(function(response) {
//                   alert('Report sent successfully to safety authorities!');
//                   document.getElementById('unsafe-description').value = '';
//               }, function(error) {
//                   alert('Failed to send report: ' + JSON.stringify(error));
//               });

//       }, (error) => {
//           alert('Failed to fetch your location: ' + error.message);
//       });
//   } else {
//       alert('Geolocation is not supported by your browser.');
//   }
// });


// Add this in script.js or directly in a <script> tag after emailjs is loaded

// Initialize EmailJS
(function () {
  emailjs.init("s-YzKNJQcVc7SeGHm"); // Replace with your actual public key from EmailJS
})();

// Handle Unsafe Area Report
document.getElementById("report-unsafe-btn").addEventListener("click", () => {
  const description = document.getElementById("unsafe-description").value.trim();

  if (!description) {
    alert("Please enter a description before sending the report.");
    return;
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const timestamp = new Date().toLocaleString();

        const serviceID = "service_omjyzzn";     // Replace with your EmailJS service ID
        const templateID = "template_3sxdy0v";   // Replace with your EmailJS template ID

        const templateParams = {
          description: description,
          latitude: lat,
          longitude: lng,
          timestamp: timestamp,
          reporter_email: "dbscholarhub@gmail.com" // Optional if you want to receive who sent it
        };

        emailjs.send(serviceID, templateID, templateParams)
          .then(() => {
            alert("Report sent successfully!");
            document.getElementById("unsafe-description").value = "";
          })
          .catch((error) => {
            console.error("EmailJS Error:", error);
            alert("Failed to send report. Please try again later.");
          });
      },
      (error) => {
        alert("Could not get your location: " + error.message);
      }
    );
  } else {
    alert("Geolocation is not supported by this browser.");
  }
});

